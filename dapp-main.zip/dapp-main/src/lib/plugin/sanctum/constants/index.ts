export const SANCTUM_STAT_API_URI = "https://extra-api.sanctum.so";

export const SANCTUM_TRADE_API_URI = "https://sanctum-s-api.fly.dev";
